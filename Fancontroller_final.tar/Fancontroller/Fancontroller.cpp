// SPDX-License-Identifier: Apache-2.0
// Copyright Pionix GmbH and Contributors to EVerest
#include "Fancontroller.hpp"
#include "fan/interface_fan_controllerImpl.hpp"
#include <fcntl.h>
#include <unistd.h>
#include <sys/epoll.h>
#include <iostream>
#include <fstream>
#include <thread>
#include <fstream>
/*#include "../../GenericPowermeter/main/power_data.hpp"*/
/*#include "power_data.hpp"*/
//#include "ld-ev.hpp"
//kp
#include "../CommonSecurity/aes_utils.hpp"
#include <iterator>
#include <openssl/aes.h>
#include <openssl/rand.h>
//kp

namespace module {

Fancontroller::Fancontroller(
    const ModuleInfo& info,
    std::unique_ptr<interface_fan_controllerImplBase> impl,
    Conf& config_ref
) :
    Everest::ModuleBase(info),
    p_fan(std::move(impl)),
    config(config_ref)
{}

void Fancontroller::init() {

    invoke_init(*p_fan);


}


void Fancontroller::ready() {

     EVLOG_info << "Fancontroller is ready!";
    invoke_ready(*p_fan);

int temp = handle_read_temperature();
    EVLOG_info << "Current temperature at : " << temp;

 if (temp > config.temp_threshold) {
   turn_on_fan();
}
else {
	 EVLOG_error << "Failed to open temperature file!";
}
/*if (temp > 30000 && !fan_is_on) {
        turn_on_fan();
        fan_is_on = true;
    } else if (temp <= 50000 && fan_is_on) {
        turn_off_fan();
        fan_is_on = false;
    }*/


}

int Fancontroller::handle_read_temperature() {
    std::ifstream temp_file(config.temp_path);
    int temp = 0;
    if (temp_file.is_open()) {
        temp_file >> temp;
        temp_file.close();
    } else {
        EVLOG_error << "Failed to open temperature file!";
    }
    return temp;
}
void Fancontroller::turn_on_fan() {
    std::ofstream fan_file(config.cooling_path);
    if (!fan_file.is_open()) {
        EVLOG_error << "Failed to open /sys/class/thermal/cooling_device0/cur_state"<< config.cooling_path;
        return;
    }

    //fan_file << "1";
    fan_file << config.on_value;
    fan_file.close();
    EVLOG_info << "Fan turned ON wrote value " << config.on_value ;

    //fan_file.close();


}
/*void Fancontroller::turn_off_fan() {
    std::ofstream fan_file("/sys/class/thermal/cooling_device0/cur_state");
    if (!fan_file.is_open()) {
        EVLOG_error << "Failed to open /sys/class/thermal/cooling_device0/cur_state";
        return;
    }

    fan_file << "0";
    EVLOG_info << "Fan turned OFF";

}*/

void Fancontroller::send_data_to_display(int temperature, bool fan_on) {
    if (!display_ptr) {
        EVLOG_error << "Display interface pointer is NULL — cannot send data.";
        return;
    }

    // Prepare message
    std::stringstream msg;
    msg << "Temp: " << temperature << " Fan: " << (fan_on ? "ON" : "OFF");

    // Send encrypted or plain data (depending on your setup)
    EVLOG_info << "Sending data to Display: " << msg.str();

    try {
        display_ptr->call_send_fan_data(msg.str());
    } catch (const std::exception &e) {
        EVLOG_error << "Error sending data to Display: " << e.what();
    }
}


} // namespace module
