// SPDX-License-Identifier: Apache-2.0
// Copyright Pionix GmbH and Contributors to EVerest

#include "interface_fan_controllerImpl.hpp"
#include <iostream>
#include <algorithm>


namespace module {
namespace fan {
/*
std::vector<unsigned char> AES_KEY;
std::vector<unsigned char> AES_IV;

std::vector<unsigned char> read_key_from_file(const std::string &path) {
    std::ifstream file(path, std::ios::binary);
    if (!file.is_open()) {
        std::cerr << "Error: Unable to open key file: " << path << std::endl;
        return {};
    }
    std::vector<unsigned char> key((std::istreambuf_iterator<char>(file)), {});
    return key;
}
*/

void interface_fan_controllerImpl::init() {

/* AES_KEY = read_key_from_file("/home/phytec/Everest/everest-dev-environment/everest-core/modules/CommonSecurity/aes_key.txt");
    AES_IV  = read_key_from_file("/home/phytec/Everest/everest-dev-environment/everest-core/modules/CommonSecurity/aes_iv.txt");

    if (AES_KEY.empty() || AES_IV.empty()) {
        EVLOG_error << "Failed to load AES key or IV!";
    } else {
        EVLOG_info << "AES key and IV loaded successfully!";
    }*/

// EVLOG_info << "FanController: init() called — Initialization phase started";
}

void interface_fan_controllerImpl::ready() {
   //  EVLOG_info << "Fan controller ready. Using cooling path: " << cooling_path;
}

bool interface_fan_controllerImpl::handle_turn_on() {
    return false;
}

bool interface_fan_controllerImpl::handle_turn_off() {
    // your code for cmd turn_off goes here
	return false;
}

int interface_fan_controllerImpl::handle_read_temperature() {
    std::ifstream temp_file("/sys/class/thermal/thermal_zone0/temp");
    int temp = 0;
    if (temp_file.is_open()) {
        temp_file >> temp;
        temp_file.close();
    } else {
        EVLOG_error << "Failed to open temperature file!";
    }
    return temp;
}

} // namespace fan
} // namespace module
