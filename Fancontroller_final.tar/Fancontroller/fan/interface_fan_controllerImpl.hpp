// SPDX-License-Identifier: Apache-2.0
// Copyright Pionix GmbH and Contributors to EVerest
#ifndef FAN_INTERFACE_FAN_CONTROLLER_IMPL_HPP
#define FAN_INTERFACE_FAN_CONTROLLER_IMPL_HPP

//
// AUTO GENERATED - MARKED REGIONS WILL BE KEPT
// template version 3
//

#include <generated/interfaces/interface_fan_controller/Implementation.hpp>

#include "../Fancontroller.hpp"
#include <fstream>

// ev@75ac1216-19eb-4182-a85c-820f1fc2c091:v1
// insert your custom include headers here
// ev@75ac1216-19eb-4182-a85c-820f1fc2c091:v1
namespace module {
class Fancontroller;  
}

namespace module {
namespace fan {

struct Conf {
std::string cooling_path;
    int on_value;
    int off_value;
}; 

class interface_fan_controllerImpl : public interface_fan_controllerImplBase {
public:
    interface_fan_controllerImpl() = delete;
    interface_fan_controllerImpl(Everest::ModuleAdapter* ev, const Everest::PtrContainer<Fancontroller>& mod,
                                 Conf& config) :
        interface_fan_controllerImplBase(ev, "fan"), mod(mod), config(config){};
     bool handle_turn_on() override;
     bool handle_turn_off()override;
 int handle_read_temperature()override; 

    
 //int handle_read_temperature() override;

    // ev@8ea32d28-373f-4c90-ae5e-b4fcc74e2a61:v1
    // insert your public definitions here
    // ev@8ea32d28-373f-4c90-ae5e-b4fcc74e2a61:v1

protected:
    // command handler functions (virtual)
  //  virtual std::string handle_turn_on() override;
   // virtual std::string handle_turn_off() override;
//    virtual std::string handle_set_speed(int& speed) override;

    // ev@d2d1847a-7b88-41dd-ad07-92785f06f5c4:v1
    // insert your protected definitions here
    // ev@d2d1847a-7b88-41dd-ad07-92785f06f5c4:v1

private:
    const Everest::PtrContainer<Fancontroller>& mod;
    const Conf& config;
   
   // std::string cooling_path;
    //std::string on_value;
    //std::string off_value;



    void init() override;
    void ready() override;
     //bool is_on_ = false;
     //int speed_ = 0;

    // ev@3370e4dd-95f4-47a9-aaec-ea76f34a66c9:v1
    // insert your private definitions here
    // ev@3370e4dd-95f4-47a9-aaec-ea76f34a66c9:v1
};

// ev@3d7da0ad-02c2-493d-9920-0bbbd56b9876:v1
// insert other definitions here
// ev@3d7da0ad-02c2-493d-9920-0bbbd56b9876:v1

} // namespace fan
} // namespace module

#endif // FAN_INTERFACE_FAN_CONTROLLER_IMPL_HPP
