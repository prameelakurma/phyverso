// SPDX-License-Identifier: Apache-2.0
// Copyright Pionix GmbH and Contributors to EVerest

#include "interface_fan_controllerImpl.hpp"
#include <iostream>
#include <algorithm>


namespace module {
namespace fan {

void interface_fan_controllerImpl::init() {
//	std::cout << "[Fan Controller] Initialized." << std::endl;
//	is_on_ = false;
//    speed_ = 0;
EVLOG_info << "FanController config: "
               << "path=" << config.cooling_path
               << ", on=" << config.on_value
               << ", off=" << config.off_value;



 EVLOG_info << "FanController: init() called — Initialization phase started";
}

void interface_fan_controllerImpl::ready() {
    //cooling_path = mod->config.cooling_path;
    //on_value = std::to_string(mod->config.on_value);
    //off_value = std::to_string(mod->config.off_value);
/*cooling_path = config.cooling_path;
on_value = std::to_string(config.on_value);
off_value = std::to_string(config.off_value);*/
/*if (cooling_path.empty()) {
        EVLOG_error << "cooling_path is empty!";
        throw std::runtime_error("Invalid config: cooling_path not set");
    }*/

    try {
        cooling_path = config.get_cooling_path();
        on_value = std::to_string(config.get_on_value());
        off_value = std::to_string(config.get_off_value());
        
        EVLOG_info << "Fan controller ready. Config:";
        EVLOG_info << "  Path: " << cooling_path;
        EVLOG_info << "  On: " << on_value;
        EVLOG_info << "  Off: " << off_value;
    } catch (const std::exception& e) {
        EVLOG_error << "Failed to process config: " << e.what();
        throw;
    }

    // Explicitly convert integers to strings (defensive programming)
   

    EVLOG_info << "Fan controller ready. Using cooling path: " << cooling_path;
}

bool interface_fan_controllerImpl::handle_turn_on() {
    // your code for cmd turn_on goes here
   /* std::ofstream fan_file(cooling_path);
    if (!fan_file.is_open()) {
        EVLOG_error << "Failed to open cooling path: " << cooling_path;
        return "error";
    }
    fan_file << on_value;
    fan_file.close();
    EVLOG_info << "Fan turned ON (wrote " << on_value << ")";
    return "fan_on";*/
    std::ofstream fan_file(cooling_path);
    fan_file << on_value;
    return fan_file.good() ? "ok" : "error";
    //return "everest";
}

bool interface_fan_controllerImpl::handle_turn_off() {
    // your code for cmd turn_off goes here
 /*std::ofstream fan_file(cooling_path);
    if (!fan_file.is_open()) {
        EVLOG_error << "Failed to open cooling path: " << cooling_path;
        return "error";
    }
    fan_file << off_value;
    fan_file.close();
    EVLOG_info << "Fan turned OFF (wrote " << off_value << ")";
    return "fan_off";*/
	std::ofstream fan_file(cooling_path);
    fan_file << off_value;
    return fan_file.good() ? "ok" : "error";
}

/*std::string interface_fan_controllerImpl::handle_set_speed(int& speed) {
    // your code for cmd set_speed goes here
 EVLOG_warning << "Fan speed control not supported. Ignoring speed: " << speed;
    return "not_supported";
}*/

} // namespace fan
} // namespace module
