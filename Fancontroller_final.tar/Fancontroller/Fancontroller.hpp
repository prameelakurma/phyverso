// SPDX-License-Identifier: Apache-2.0
// Copyright Pionix GmbH and Contributors to EVerest

#ifndef FANCONTROLLER_HPP
#define FANCONTROLLER_HPP

#include "ld-ev.hpp"
#include "fan/interface_fan_controllerImpl.hpp"
#include <generated/interfaces/interface_fan_controller/Implementation.hpp>
#include <nlohmann/json.hpp>

namespace module {

/*struct Conf {
    std::string cooling_path;
    int on_value;
    int off_value;
};*/
struct Conf {
    std::string cooling_path;
    std::string temp_path;
    int on_value;
    int off_value;
    int temp_threshold;
};

class Fancontroller : public Everest::ModuleBase {
public:
	Fancontroller() = delete;
    Fancontroller(const ModuleInfo&,
                  std::unique_ptr<interface_fan_controllerImplBase>,
                  Conf&);
// ModuleBase(info), p_fan(std::move(p_fan)), config(config){};
    // existing members…
    const std::unique_ptr<interface_fan_controllerImplBase> p_fan;
    const Conf& config;
   // bool handle_turn_on() ;
    // bool handle_turn_off();
    int handle_read_temperature();
//int read_all_trip_points();
void turn_on_fan();
void turn_off_fan();
    void init();
    void ready();
    // Function to send data
    void send_data_to_display(int temperature, bool fan_on);


     //std::string handle_turn_on()  override;
     //std::string handle_turn_off() override;


private:
    friend class LdEverest;
   // void init();
    //void ready();
//bool fan_is_on = false;
 std::shared_ptr<fan_display_interface_client> display_ptr;  // Pointer to Display interface

};

} // namespace module

#endif // FANCONTROLLER_HPP
