// SPDX-License-Identifier: Apache-2.0
// Copyright Pionix GmbH and Contributors to EVerest
#ifndef FANCONTROLLER_HPP
#define FANCONTROLLER_HPP

//
// AUTO GENERATED - MARKED REGIONS WILL BE KEPT
// template version 2
//

#include "ld-ev.hpp"
#include "fan/interface_fan_controllerImpl.hpp"
// headers for provided interface implementations
#include <generated/interfaces/interface_fan_controller/Implementation.hpp>
// ev@4bf81b14-a215-475c-a1d3-0a484ae48918:v1
// insert your custom include headers here
// ev@4bf81b14-a215-475c-a1d3-0a484ae48918:v1

namespace module {

struct Conf {
  std::string cooling_path;
    int on_value;
    int off_value;
	//  bool gpio_invert;
};

class Fancontroller : public Everest::ModuleBase {
//class Fancontroller :
  //  public Everest::ModuleBaseWithConfAndProvided<Conf, Provides>

public:
    Fancontroller() = delete;
    Fancontroller(const ModuleInfo& info, std::unique_ptr<interface_fan_controllerImplBase> p_fan, Conf& config) :
        ModuleBase(info), p_fan(std::move(p_fan)), config(config){};

    const std::unique_ptr<interface_fan_controllerImplBase> p_fan;
    const Conf& config;

    // ev@1fce4c5e-0ab8-41bb-90f7-14277703d2ac:v1
    // insert your public definitions here
    // ev@1fce4c5e-0ab8-41bb-90f7-14277703d2ac:v1

protected:
    // ev@4714b2ab-a24f-4b95-ab81-36439e1478de:v1
    // insert your protected definitions here
    // ev@4714b2ab-a24f-4b95-ab81-36439e1478de:v1
//std::unique_ptr<interface_fan_controller> p_fan;
private:
    friend class LdEverest;
    void init();
    void ready();

    //std::unique_ptr<interface_fan_controllerImplBase> p_fan;
    //Conf config;
    // ev@211cfdbe-f69a-4cd6-a4ec-f8aaa3d1b6c8:v1
    // insert your private definitions here
    // ev@211cfdbe-f69a-4cd6-a4ec-f8aaa3d1b6c8:v1
};


//};

/*class Fancontroller {
public:
    Fancontroller(Everest::ModuleAdapter* module_adapter,
                  const Everest::PtrContainer<Fancontroller>& self_ref)
        : module_adapter(module_adapter), self(self_ref) {}

    void init();
    void ready();

private:
    Everest::ModuleAdapter* module_adapter;
    Everest::PtrContainer<Fancontroller> self;

    std::unique_ptr<module::fan::interf*/



// ev@087e516b-124c-48df-94fb-109508c7cda9:v1
// insert other definitions here
// ev@087e516b-124c-48df-94fb-109508c7cda9:v1

//};
}// namespace module

#endif // FANCONTROLLER_HPP
