// SPDX-License-Identifier: Apache-2.0
// Copyright Pionix GmbH and Contributors to EVerest
#include "TH40F10030C8L.hpp"

namespace module {
//namespace main {
void TH40F10030C8L::init() {
    invoke_init(*p_main);
}

void TH40F10030C8L::ready() {
    invoke_ready(*p_main);
}

} // namespace module
//}
