#pragma once

#include <generated/interfaces/power_supply_DC/Implementation.hpp>
#include "../TH40F10030C8L.hpp"

#include <linux/can.h>
#include <linux/can/raw.h>

//kp
#include "../can_driver/CanBus.hpp"
#include "../can_driver/TonheCanDevice.hpp"
//kp

namespace module {
namespace main {

/* REQUIRED because manifest has:
 * provides:
 *   main:
 *     config: {}
 */
struct Conf {
    // intentionally empty (same as InfyPower)
};

class power_supply_DCImpl : public power_supply_DCImplBase {

public:
    power_supply_DCImpl(Everest::ModuleAdapter* adapter,
                        const Everest::PtrContainer<TH40F10030C8L>& mod,
                        Conf& cfg);

    ~power_supply_DCImpl() override= default;

    void init() override;
    void ready() override;
    void on_rx(uint32_t can_id,
               const std::vector<uint8_t>& data);

protected:
    void handle_setMode(types::power_supply_DC::Mode& mode,
                        types::power_supply_DC::ChargingPhase& phase) override;

    void handle_setExportVoltageCurrent(double& voltage,
                                        double& current) override;

    void handle_setImportVoltageCurrent(double& voltage,
                                        double& current) override;

private:

    const Everest::PtrContainer<TH40F10030C8L>& mod;
    Conf& cfg;
     bool fault_latched = false;

    std::unique_ptr<CanBus> can;
    std::unique_ptr<TonheCanDevice> tonhe;
    // internal helpers (controller simulation)
/*    void apply_mode(bool enable);
    void apply_voltage_current(double voltage, double current);

    const Everest::PtrContainer<TH40F10030C8L>& mod;
    Conf& cfg;

    std::unique_ptr<CanBus> can;
    std::unique_ptr<TonheCanDevice> tonhe;*/
        double last_voltage = 0.0;
    double last_current = 0.0;
    uint8_t last_status = 0;

    bool response_received = false;

};

} // namespace main
} // namespace module

