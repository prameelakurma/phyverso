#include "power_supply_DCImpl.hpp"

#include <everest/logging.hpp>
#include <algorithm>

namespace module {
namespace main {

power_supply_DCImpl::power_supply_DCImpl(
    Everest::ModuleAdapter* adapter,
    const Everest::PtrContainer<TH40F10030C8L>& mod,
    Conf& cfg)
    : power_supply_DCImplBase(adapter, "main")
    , mod(mod)
    , cfg(cfg) {}

void power_supply_DCImpl::init() {
    const auto& c = mod->config;

    EVLOG_info << "Initializing Tonhe power supply";

     if (c.can_device.empty()) {
        EVLOG_error << "CAN device is EMPTY! Check manifest.yaml";
        return;
    }

    can = std::make_unique<CanBus>(c.can_device);
//    tonhe = std::make_unique<TonheCanDevice>(*can, c.master_address, c.module_address);
    tonhe = std::make_unique<TonheCanDevice>(*can, 160, 1);
    tonhe->status_cb =
    [this](double v, double i) {

        types::power_supply_DC::VoltageCurrent vc;
        vc.voltage_V = v;
        vc.current_A = i;

        EVLOG_info << "Publishing to EVerest V=" << v
                   << " I=" << i;

   //     this->p_main->publish_voltage_current(vc);
    };
}

void power_supply_DCImpl::ready() {
    EVLOG_info << "TH40F10030C8L ready";

      //double voltage = c.max_voltage_V;
     // double current = c.max_current_A;
    double voltage = 100.0;
    double current = 16.0;
            // Call controller path (this is the KEY)
    handle_setExportVoltageCurrent(voltage, current);


}

void power_supply_DCImpl::handle_setMode(
    types::power_supply_DC::Mode& mode,
    types::power_supply_DC::ChargingPhase&) {


bool enable = (mode != types::power_supply_DC::Mode::Off);

    EVLOG_info << "Controller setMode → "
               << (enable ? "ENABLE" : "DISABLE");

    tonhe->controller_enable(enable);



}

void power_supply_DCImpl::handle_setExportVoltageCurrent(
    double& voltage, double& current) {


	const auto& c = mod->config;

    EVLOG_info << "Controller requested V=" << voltage
               << " I=" << current;

    // 🔒 If already in fault → DO NOTHING
    if (fault_latched) {
        EVLOG_warning << "Fault latched → ignoring V/I commands";
        return;
    }

    bool voltage_ok = (voltage >= 0.0 &&
                       voltage <= c.max_voltage_V);

    bool current_ok = (current >= 0.0 &&
                       current <= c.max_current_A);

    bool stop = false;
    if (!voltage_ok || !current_ok) {

        EVLOG_error << "❌ OUT OF RANGE!"
                    << " V=" << voltage
                    << " allowed[0–" << c.max_voltage_V << "]"
                    << " I=" << current
                    << " allowed[0–" << c.max_current_A << "]";

        //tonhe->controller_enable(false);
        tonhe->controller_set_voltage_current(0, 0, true);
	 fault_latched = true;
	//stop = true; 
        return;
        
    }
    //tonhe->controller_enable(true);
    tonhe->controller_set_voltage_current(voltage, current,false);




}

void power_supply_DCImpl::handle_setImportVoltageCurrent(
    double& voltage, double& current) {


 handle_setExportVoltageCurrent(voltage, current);
	
}

} // namespace main
} // namespace module

