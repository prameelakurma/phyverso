/*#pragma once

#include <linux/can.h>
#include <cstdint>

namespace TonheCanPackets {

// Controller → Module
struct can_frame make_enable(uint8_t sa, bool on);
struct can_frame make_set_vi(uint8_t sa, double voltage, double current);

// Module → Controller
struct can_frame make_status(uint8_t sa, bool enabled);

} */// namespace TonheCanPackets
 #pragma once
#include <linux/can.h>
#include <cstdint>

namespace TonheCanPackets {

uint32_t make_can_id(uint8_t module_addr, uint8_t controller_addr);

struct can_frame make_enable(uint8_t module_addr,
                             uint8_t controller_addr,
                             bool on);

struct can_frame make_set_vi(uint8_t module_addr,
                             uint8_t controller_addr,
                             double voltage,
                             double current,bool stop);

} 

