/*#include "TonheCanDevice.hpp"
#include "TonheCanPackets.hpp"

TonheCanDevice::TonheCanDevice(CanBus& b,
                               uint8_t master,
                               uint8_t module)
    : bus(b), master_addr(master), module_addr(module) {}

void TonheCanDevice::controller_enable(bool on) {
    auto frame = TonheCanPackets::make_enable(master_addr, on);
    bus.send(frame);
}

void TonheCanDevice::controller_set_voltage_current(double v, double i) {
    auto frame = TonheCanPackets::make_set_vi(master_addr, v, i);
    bus.send(frame);
}

void TonheCanDevice::process_rx() {
    struct can_frame frame{};
    if (!bus.receive(frame))
        return;

    // For now just log or ignore
}
*/
#include "TonheCanDevice.hpp"
#include "TonheCanPackets.hpp"
#include <everest/logging.hpp>

TonheCanDevice::TonheCanDevice(CanBus& b,
                               uint8_t master,
                               uint8_t module)
    : bus(b),
      master_addr(master),
      module_addr(module) {
	       EVLOG_info << "Tonhe CAN addr: master="
               << int(master_addr)
	       << " module=" << int(module_addr);


	        // 🔥 CONNECT RX CALLBACK
    bus.set_rx_callback ( [this](uint32_t can_id,
                             const std::vector<uint8_t>& data) {
        this->on_rx(can_id, data);
    }
    );
}

void TonheCanDevice::controller_enable(bool on) {
    auto frame = TonheCanPackets::make_enable(
        module_addr,
        master_addr,
        on
    );
    bus.send(frame);
}

void TonheCanDevice::controller_set_voltage_current(double v, double i,bool stop) {
    auto frame = TonheCanPackets::make_set_vi(
        module_addr,
        master_addr,
        v,
        i,
	stop
    );
    bus.send(frame);
}

void TonheCanDevice::on_rx(uint32_t can_id,
                           const std::vector<uint8_t>& data) {


uint8_t src_addr = (can_id >> 8) & 0xFF;
uint8_t dst_addr =  can_id & 0xFF;

if (src_addr == master_addr &&
    dst_addr == module_addr)
{

    EVLOG_info << "RX ACCEPTED | SRC=0x"
               << std::hex << int(src_addr)
               << " DST=0x" << int(dst_addr);

/*    uint8_t module_id = data[0];

    uint16_t raw_voltage =
        (uint16_t)data[1] |
        ((uint16_t)data[2] << 8);

    uint16_t raw_current =
        (uint16_t)data[3] |
        ((uint16_t)data[4] << 8);

    uint8_t status = data[5];*/
     /* ✅ TX-style RX PRINT */
    std::ostringstream rx;
    rx << "CAN RX -> id=0x"
       << std::hex << std::uppercase << can_id
       << " dlc=" << std::dec << data.size()
       << " data=";

    for (uint8_t b : data) {
        rx << std::hex << std::setw(2)
           << std::setfill('0') << int(b) << " ";
    }

    EVLOG_info << rx.str();

    /* ✅ Decode payload */
    if (data.size() < 6)
        return;

}
else 
{
    EVLOG_warning << "RX REJECTED | SRC=0x"
               << std::hex << int(src_addr)
               << " DST=0x" << int(dst_addr);
    return;



}
}




/*void TonheCanDevice::on_rx(uint32_t can_id,
                           const std::vector<uint8_t>& data) {

    uint8_t src_addr = (can_id >> 8) & 0xFF;
    uint8_t dst_addr =  can_id & 0xFF;

    // ✅ STRICT MATCH (Tonhe → Everest)
    if (src_addr != master_addr ||
        dst_addr != module_addr) {
        return;   // ❌ DROP FRAME
    }

    // ✅ ACCEPTED FRAME
    EVLOG_info << "RX ACCEPTED | SRC=0x"
               << std::hex << int(src_addr)
               << " DST=0x" << int(dst_addr);

    
     // ✅ TX-STYLE RX LOG
    std::ostringstream oss;
    oss << "CAN RX -> id=0x"
        << std::uppercase
        << std::hex
        << std::setw(8)
        << std::setfill('0')
        << can_id
        << " dlc=" << std::dec << data.size()
        << " data=";

    for (uint8_t b : data) {
        oss << std::hex
            << std::setw(2)
            << std::setfill('0')
            << int(b) << " ";
    }

    EVLOG_info << oss.str();

}*/

