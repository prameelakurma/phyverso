#include "CanBus.hpp"

#include <cstring>
#include <stdexcept>
#include <unistd.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <sys/socket.h>
#include <linux/can/raw.h>
#include <sstream>

#include <everest/logging.hpp>   // ✅ ADD THIS
#include <iomanip>

CanBus::CanBus(const std::string& ifname) {
    sock = socket(PF_CAN, SOCK_RAW, CAN_RAW);
    if (sock < 0)
        throw std::runtime_error("CAN socket create failed");

    struct ifreq ifr {};
    std::strncpy(ifr.ifr_name, ifname.c_str(), IFNAMSIZ - 1);
    if (ioctl(sock, SIOCGIFINDEX, &ifr) < 0)
        throw std::runtime_error("CAN ioctl failed");

    struct sockaddr_can addr {};
    addr.can_family  = AF_CAN;
    addr.can_ifindex = ifr.ifr_ifindex;

    if (bind(sock, reinterpret_cast<struct sockaddr*>(&addr), sizeof(addr)) < 0)
        throw std::runtime_error("CAN bind failed");


    rx_thread_handle = std::thread(&CanBus::rx_thread, this);
}

CanBus::~CanBus() {
	 exit_rx_thread = true;

    if (rx_thread_handle.joinable())
        rx_thread_handle.join();
    if (sock >= 0)
        close(sock);
}

void CanBus::set_rx_callback(RxCallback cb)
{
    rx_callback = std::move(cb);
}


void CanBus::send(const struct can_frame& frame) {

	std::ostringstream oss;

/*    oss << "CAN TX -> id=0x"
        << std::hex << frame.can_id
        << " dlc=" << std::dec << int(frame.can_dlc)
        << " data=";*/
	oss << "CAN TX -> id=0x"
    << std::uppercase
    << std::hex
    << std::setw(8)
    << std::setfill('0')
    << frame.can_id
    << " dlc=" << std::dec << int(frame.can_dlc)
    << " data=";

    for (int i = 0; i < frame.can_dlc; i++) {
        oss << std::hex
            << std::setw(2)
            << std::setfill('0')
            << int(frame.data[i]) << " ";
    }

    EVLOG_info << oss.str();


    ssize_t ret = write(sock, &frame, sizeof(frame));
    if (ret != sizeof(frame))
	    EVLOG_error << "CAN write failed (ignored in simulation)";
}


void CanBus::rx_thread() {
    struct can_frame frame{};

    while (!exit_rx_thread) {
        if (read(sock, &frame, sizeof(frame)) != sizeof(frame))
            continue;

        if (frame.can_id & CAN_ERR_FLAG) continue;
        if (frame.can_id & CAN_RTR_FLAG) continue;

        uint32_t can_id = frame.can_id & CAN_EFF_MASK;

        // ✅ CALL on_rx ONLY IF MATCH
        if (rx_callback) {
            rx_callback(
                can_id,
                std::vector<uint8_t>(
                    frame.data,
                    frame.data + frame.can_dlc
                )
            );
        }
    }
}
