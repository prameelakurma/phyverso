/*#pragma once
#include <linux/can.h>
#include <string>
class CanBus {
public:
    explicit CanBus(const std::string& ifname);
    ~CanBus();

    void send(const can_frame& frame);
    bool receive(can_frame& frame);
     int get_fd() const;   // ✅ ADD THIS

private:
    int sock;
};
*/
#pragma once
#include <linux/can.h>
#include <thread>
#include <functional>
#include <vector>
#include <string>
#include<atomic>

class CanBus {
public:
        using RxCallback = std::function<void(uint32_t, const std::vector<uint8_t>&)>;


    explicit CanBus(const std::string& ifname);
    ~CanBus();

    void send(const struct can_frame& frame);
    void set_rx_callback(RxCallback cb);
    void start_rx();

    // RX callback
    //std::function<void(uint32_t, const std::vector<uint8_t>&)> rx_callback;

private:
/*    int sock;
    bool exit_rx_thread{false};
    std::thread rx_thread_handle;

    void rx_thread();   // 👈 ADD THIS*/

    int sock{-1};
    std::thread rx_thread_handle;
    std::atomic<bool> exit_rx_thread{false};
    RxCallback rx_callback;
    void rx_thread();
};

