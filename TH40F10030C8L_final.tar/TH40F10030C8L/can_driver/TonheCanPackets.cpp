
#include "TonheCanPackets.hpp"

namespace TonheCanPackets {

uint32_t make_can_id(uint8_t module, uint8_t controller) {
    return 0x08060000 | (module << 8) | controller;
}

struct can_frame make_enable(uint8_t module,
                             uint8_t controller,
                             bool on) {
    struct can_frame f{};
    f.can_id  = make_can_id(module, controller);
    f.can_dlc = 8;

    f.data[0] = 0xAA;          // START
   // f.data[1] = module;
    f.data[1] = 0x01;
   // f.data[2] = controller;
    f.data[2] = 0xa0;
    f.data[3] = on ? 0x01 : 0x00;
    f.data[4] = 0x00;
    f.data[5] = 0x00;
    f.data[6] = 0x00;
    f.data[7] = 0x00;

    return f;
}

struct can_frame make_set_vi(uint8_t module,
                             uint8_t controller,
                             double voltage,
                             double current,bool stop) {
    struct can_frame f{};
    f.can_id  = make_can_id(module, controller);
    f.can_dlc = 8;

     uint16_t v = voltage * 10;   // 400.0 → 4000
      uint16_t i = current * 100;  // 100.0 → 10000
 
    // 🔥 VENDOR RULE
    f.data[0] = stop ? 0x55 : 0xAA;   // START / STOP
    f.data[1] = module;

    if (stop) {
        f.data[2] = 0x00;
        f.data[3] = 0x00;
        f.data[4] = 0x00;
        f.data[5] = 0x00;
    } else {
        f.data[2] = v & 0xFF;
        f.data[3] = (v >> 8) & 0xFF;
        f.data[4] = i & 0xFF;
        f.data[5] = (i >> 8) & 0xFF;
    }

    f.data[6] = 0x00;
    f.data[7] = 0x00;



    return f;
}

} // namespace TonheCanPackets

