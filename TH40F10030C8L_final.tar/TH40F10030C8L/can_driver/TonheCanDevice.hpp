/*#pragma once

#include "CanBus.hpp"
#include <cstdint>

class TonheCanDevice {
public:
    TonheCanDevice(CanBus& bus,
                   uint8_t master_addr,
                   uint8_t module_addr);

    void controller_enable(bool on);
    void controller_set_voltage_current(double v, double i);
    void process_rx();

private:
    CanBus& bus;
    uint8_t master_addr;
    uint8_t module_addr;
};
*/
#pragma once
#include "CanBus.hpp"
#include <cstdint>
#include <functional>
#include <vector>

class TonheCanDevice {
public:
    TonheCanDevice(CanBus& bus,
                   uint8_t master_addr,
                   uint8_t module_addr);

    void controller_enable(bool on);
    void controller_set_voltage_current(double v, double i,bool stop);

    std::function<void(double voltage, double current)> status_cb;

    void on_rx(uint32_t can_id,
               const std::vector<uint8_t>& data);

private:
    CanBus& bus;
    uint8_t master_addr;
    uint8_t module_addr;
};

