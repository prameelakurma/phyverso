#pragma once
#include <cstdint>

namespace tonhe::conv {

inline uint16_t u16_be(const uint8_t* d) {
    return (uint16_t(d[0]) << 8) | d[1];
}

inline double voltage(uint16_t raw) {
    return raw * 0.1;   // 0.1 V / bit
}

inline double current(uint16_t raw) {
    return raw * 0.1;   // 0.1 A / bit
}

inline uint16_t raw_voltage(double v) {
    return static_cast<uint16_t>(v * 10);
}

inline uint16_t raw_current(double i) {
    return static_cast<uint16_t>(i * 10);
}

} // namespace tonhe::conv

