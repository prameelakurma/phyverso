// SPDX-License-Identifier: Apache-2.0
#pragma once


#include "ld-ev.hpp"
#include <generated/interfaces/power_supply_DC/Implementation.hpp>


namespace module {
//namespace main {

struct Conf {
std::string can_device;
int master_address;
int module_address;
double nominal_power_W;
double max_voltage_V;
double max_current_A;
int periodic_status_ms;
};


class TH40F10030C8L : public Everest::ModuleBase {
public:
TH40F10030C8L() = delete;
TH40F10030C8L(const ModuleInfo& info,
std::unique_ptr<power_supply_DCImplBase> p_main,
Conf& config)
: ModuleBase(info), p_main(std::move(p_main)), config(config) {}


const std::unique_ptr<power_supply_DCImplBase> p_main;
const Conf& config;


private:
friend class LdEverest;
void init();
void ready();
};


} // namespace module
//}
