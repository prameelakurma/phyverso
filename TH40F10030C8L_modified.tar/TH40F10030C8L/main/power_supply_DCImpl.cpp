#include "power_supply_DCImpl.hpp"
#include <everest/logging.hpp>
//#include "can/can_tonhe.hpp"
namespace module {
namespace main {

void power_supply_DCImpl::init() {
    EVLOG_info << "[TH40F10030C8L] init";

    const auto& cfg = mod->config;
    
  /*  if (!can.open(cfg.can_device)) {
        EVLOG_error << "Failed to open CAN device " << cfg.can_device;
        return;
    }*/
     //can = std::make_unique<TonheCAN>();

    /*if (!can->open(cfg.can_device)) {
        EVLOG_error << "Failed to open CAN device " << cfg.can_device;
        return;
    }*/

    caps.bidirectional = false;
    caps.min_export_voltage_V = 0;
    caps.max_export_voltage_V = cfg.max_voltage_V;
    caps.min_export_current_A = 0;
    caps.max_export_current_A = cfg.max_current_A;
    caps.max_export_power_W = cfg.nominal_power_W;
    caps.conversion_efficiency_export = 0.95;

    EVLOG_info << "[TH40F10030C8L] CAN device from manifest: "
               << cfg.can_device;
}

void power_supply_DCImpl::ready() {
    publish_capabilities(caps);
    publish_mode(types::power_supply_DC::Mode::Off);
}

void power_supply_DCImpl::handle_setMode(types::power_supply_DC::Mode& mode,
                                         types::power_supply_DC::ChargingPhase&) {
    EVLOG_info << "Mode set";
      EVLOG_info << "Mode = " << static_cast<int>(mode);
    publish_mode(mode);
}

void power_supply_DCImpl::handle_setExportVoltageCurrent(double& voltage,
                                                         double& current) {
    EVLOG_info << "Set V/I";
 /*    const auto& cfg = mod->config;

    // Clamp
    voltage = std::min(voltage, cfg.max_voltage_V);
    current = std::min(current, cfg.max_current_A);

    bool ok = can.send_set_voltage_current(
        voltage,
        current,
        cfg.master_address,
        cfg.module_address
    );

    if (!ok) {
        EVLOG_error << "CAN send failed";
        return;
    }

    EVLOG_info << "Sent V=" << voltage << " I=" << current;

    types::power_supply_DC::VoltageCurrent vc;
    vc.voltage_V = voltage;
    vc.current_A = current;
    publish_voltage_current(vc);*/
}

void power_supply_DCImpl::handle_setImportVoltageCurrent(double& voltage,
                                                         double& current) {
    voltage = 0;
    current = 0;
}

} // namespace main
} // namespace module

