#ifndef MAIN_POWER_SUPPLY_DC_IMPL_HPP
#define MAIN_POWER_SUPPLY_DC_IMPL_HPP

#include <generated/interfaces/power_supply_DC/Implementation.hpp>
#include "../TH40F10030C8L.hpp"
//#include "TonheCAN.hpp" 
//#include"can/can_tonhe.hpp"
#include <mutex>

namespace module {
namespace main {

class TonheCAN;
class power_supply_DCImpl : public power_supply_DCImplBase {
public:
    power_supply_DCImpl() = delete;

    power_supply_DCImpl(Everest::ModuleAdapter* ev,
                        const Everest::PtrContainer<TH40F10030C8L>& mod) :
        power_supply_DCImplBase(ev, "main"),
        mod(mod) {}

private:
    void init() override;
    void ready() override;

    void handle_setMode(types::power_supply_DC::Mode& mode,
                        types::power_supply_DC::ChargingPhase& phase) override;

    void handle_setExportVoltageCurrent(double& voltage,
                                        double& current) override;

    void handle_setImportVoltageCurrent(double& voltage,
                                        double& current) override;

    const Everest::PtrContainer<TH40F10030C8L>& mod;

    std::mutex settings_mutex;
    // TonheCAN can;


    double export_voltage_V{0.0};
    double export_current_A{0.0};

    types::power_supply_DC::Capabilities caps;
    types::power_supply_DC::Mode last_mode{types::power_supply_DC::Mode::Off};
};

} // namespace main
} // namespace module

#endif

