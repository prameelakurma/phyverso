#ifndef CAN_TONHE_HPP
#define CAN_TONHE_HPP

#include <string>
#include <linux/can.h>   // sockaddr_can

class TonheCAN {
public:
    bool open(const std::string& ifname);
    void close();

    bool send_set_voltage_current(double voltage, double current);
    bool send_enable(bool enable);

private:
    int sock{-1};
    struct sockaddr_can addr {};   // ✅ FIX
};

#endif

