#include "can_tonhe.hpp"

#include <sys/socket.h>
#include <sys/ioctl.h>     // ✅ REQUIRED
#include <net/if.h>
#include <unistd.h>
#include <cstring>
#include <linux/can/raw.h>

bool TonheCAN::open(const std::string& ifname) {
    sock = socket(PF_CAN, SOCK_RAW, CAN_RAW);
    if (sock < 0)
        return false;

    struct ifreq ifr {};
    std::snprintf(ifr.ifr_name, IFNAMSIZ, "%s", ifname.c_str());  // ✅ SAFE

    if (ioctl(sock, SIOCGIFINDEX, &ifr) < 0) {
        ::close(sock);
        sock = -1;
        return false;
    }

    addr.can_family = AF_CAN;
    addr.can_ifindex = ifr.ifr_ifindex;

    if (bind(sock, reinterpret_cast<struct sockaddr*>(&addr),
             sizeof(addr)) < 0) {
        ::close(sock);
        sock = -1;
        return false;
    }

    return true;
}

void TonheCAN::close() {
    if (sock >= 0) {
        ::close(sock);
        sock = -1;
    }
}

bool TonheCAN::send_set_voltage_current(double voltage, double current) {
    if (sock < 0)
        return false;

    struct can_frame frame {};
    frame.can_id = 0x18FF50E5;  // Example J1939 PGN
    frame.can_dlc = 8;

    uint16_t v = static_cast<uint16_t>(voltage * 10);
    uint16_t c = static_cast<uint16_t>(current * 10);

    frame.data[0] = v & 0xFF;
    frame.data[1] = v >> 8;
    frame.data[2] = c & 0xFF;
    frame.data[3] = c >> 8;

    return write(sock, &frame, sizeof(frame)) == sizeof(frame);
}

bool TonheCAN::send_enable(bool enable) {
    if (sock < 0)
        return false;

    struct can_frame frame {};
    frame.can_id = 0x18FF51E5;
    frame.can_dlc = 1;
    frame.data[0] = enable ? 1 : 0;

    return write(sock, &frame, sizeof(frame)) == sizeof(frame);
}

