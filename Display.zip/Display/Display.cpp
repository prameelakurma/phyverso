// SPDX-License-Identifier: Apache-2.0
// Copyright Pionix GmbH and Contributors to EVerest
#include "Display.hpp"

namespace module {

void Display::init() {
    invoke_init(*p_display);
}

void Display::ready() {
    invoke_ready(*p_display);
}

} // namespace module
