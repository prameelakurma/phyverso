// SPDX-License-Identifier: Apache-2.0
#include "display_messageImpl.hpp"

#include <fcntl.h>
#include <termios.h>
#include <unistd.h>
#include <cstring>
#include <string>
#include <iostream>
#include <map>
#include <sstream>
#include <sys/types.h>
#include <sys/stat.h>
#include <vector>
#include <thread>
#include <chrono>

namespace module {
namespace display {

// Free function declarations
int open_serial_port(const std::string& port_name);
void send_display_data(int fd, uint16_t vp_address, uint16_t value);

const std::map<int, std::pair<std::string, uint16_t>> VP_ADDRESSES = {
    {1, {"Current", 0x5000}},
    {2, {"Voltage", 0x4500}},
    {3, {"Active Power", 0x4000}},
    {4, {"Apparent Power", 0x6000}},
    {5, {"Energy", 0x6500}}
};

void display_messageImpl::init() {
    // No init logic yet
}

void display_messageImpl::ready() {
    // No ready logic yet
int fd = module::display::open_serial_port("/dev/ttyS4");
    if (fd < 0) {
        std::cerr << "Failed to open serial port." << std::endl;
        //return response;
    }

    int current_param = -1;
    std::string input;

    std::cout << "Enter parameter (0-5):\n1: Current, 2: Voltage, 3: Active Power, 4: Apparent Power, 5: Energy, 0: Done" << std::endl;

    while (true) {
        fd_set read_fds;
        FD_ZERO(&read_fds);
        FD_SET(STDIN_FILENO, &read_fds);

        struct timeval tv = {0, 10000}; // 10ms timeout
        int retval = select(STDIN_FILENO + 1, &read_fds, NULL, NULL, &tv);

        if (retval > 0 && FD_ISSET(STDIN_FILENO, &read_fds)) {
            std::getline(std::cin, input);
            if (current_param == -1) {
                int param = std::stoi(input);
                if (param == 0) continue;
                if (VP_ADDRESSES.count(param)) {
                    current_param = param;
                    std::cout << "Enter value for " << VP_ADDRESSES.at(param).first << ":" << std::endl;
                }
            } else {
                int val = std::stoi(input);
                if (val >= 0 && val <= 65535) {
                    module::display::send_display_data(fd, VP_ADDRESSES.at(current_param).second, static_cast<uint16_t>(val));
                } else {
                    std::cout << "Invalid value." << std::endl;
                }
                current_param = -1;
            }
        }

        uint8_t buffer[9];
        int n = read(fd, buffer, sizeof(buffer));
        if (n == 9 && buffer[0] == 0x5A && buffer[1] == 0xA5) {
            uint16_t vp = (buffer[4] << 8) | buffer[5];
            if (vp == 0x5500) {
                // LED control logic (optional)
            }
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }

    close(fd);
    //return response;
}

types::display_message::SetDisplayMessageResponse
display_messageImpl::handle_set_display_message(std::vector<types::display_message::DisplayMessage>& request) {
    types::display_message::SetDisplayMessageResponse response;

/*    int fd = module::display::open_serial_port("/dev/ttyS4");
    if (fd < 0) {
        std::cerr << "Failed to open serial port." << std::endl;
        return response;
    }

    int current_param = -1;
    std::string input;

    std::cout << "Enter parameter (0-5):\n1: Current, 2: Voltage, 3: Active Power, 4: Apparent Power, 5: Energy, 0: Done" << std::endl;

    while (true) {
        fd_set read_fds;
        FD_ZERO(&read_fds);
        FD_SET(STDIN_FILENO, &read_fds);

        struct timeval tv = {0, 10000}; // 10ms timeout
        int retval = select(STDIN_FILENO + 1, &read_fds, NULL, NULL, &tv);

        if (retval > 0 && FD_ISSET(STDIN_FILENO, &read_fds)) {
            std::getline(std::cin, input);
            if (current_param == -1) {
                int param = std::stoi(input);
                if (param == 0) continue;
                if (VP_ADDRESSES.count(param)) {
                    current_param = param;
                    std::cout << "Enter value for " << VP_ADDRESSES.at(param).first << ":" << std::endl;
                }
            } else {
                int val = std::stoi(input);
                if (val >= 0 && val <= 65535) {
                    module::display::send_display_data(fd, VP_ADDRESSES.at(current_param).second, static_cast<uint16_t>(val));
                } else {
                    std::cout << "Invalid value." << std::endl;
                }
                current_param = -1;
            }
        }

        uint8_t buffer[9];
        int n = read(fd, buffer, sizeof(buffer));
        if (n == 9 && buffer[0] == 0x5A && buffer[1] == 0xA5) {
            uint16_t vp = (buffer[4] << 8) | buffer[5];
            if (vp == 0x5500) {
                // LED control logic (optional)
            }
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }

    close(fd);
    return response;*/
}

types::display_message::GetDisplayMessageResponse
display_messageImpl::handle_get_display_messages(types::display_message::GetDisplayMessageRequest& request) {
    types::display_message::GetDisplayMessageResponse response;
    return response;
}

types::display_message::ClearDisplayMessageResponse
display_messageImpl::handle_clear_display_message(types::display_message::ClearDisplayMessageRequest& request) {
    types::display_message::ClearDisplayMessageResponse response;
    return response;
}

// --------------------------
// Free utility functions
// --------------------------

int open_serial_port(const std::string& port_name) {
    int fd = open(port_name.c_str(), O_RDWR | O_NOCTTY | O_SYNC);
    if (fd < 0) return -1;

    struct termios tty;
    memset(&tty, 0, sizeof tty);
    if (tcgetattr(fd, &tty) != 0) return -1;

    cfsetospeed(&tty, B115200);
    cfsetispeed(&tty, B115200);

    tty.c_cflag = (tty.c_cflag & ~CSIZE) | CS8;
    tty.c_iflag &= ~IGNBRK;
    tty.c_lflag = 0;
    tty.c_oflag = 0;
    tty.c_cc[VMIN]  = 0;
    tty.c_cc[VTIME] = 5;

    tty.c_iflag &= ~(IXON | IXOFF | IXANY);
    tty.c_cflag |= (CLOCAL | CREAD);
    tty.c_cflag &= ~(PARENB | PARODD);
    tty.c_cflag &= ~CSTOPB;
    tty.c_cflag &= ~CRTSCTS;

    if (tcsetattr(fd, TCSANOW, &tty) != 0) return -1;
    return fd;
}

void send_display_data(int fd, uint16_t vp_address, uint16_t value) {
    std::vector<uint8_t> packet = {
        0x5A, 0xA5, 0x06, 0x82,
        static_cast<uint8_t>((vp_address >> 8) & 0xFF),
        static_cast<uint8_t>(vp_address & 0xFF),
        static_cast<uint8_t>((value >> 8) & 0xFF),
        static_cast<uint8_t>(value & 0xFF)
    };

    write(fd, packet.data(), packet.size());
    tcdrain(fd);
    std::cout << "Sent packet to VP 0x" << std::hex << vp_address << std::dec << std::endl;
}

} // namespace display
} // namespace module

