// SPDX-License-Identifier: Apache-2.0
// Copyright Pionix GmbH and Contributors to EVerest
#ifndef DISPLAY_DISPLAY_MESSAGE_IMPL_HPP
#define DISPLAY_DISPLAY_MESSAGE_IMPL_HPP

//
// AUTO GENERATED - MARKED REGIONS WILL BE KEPT
// template version 3
//

#include <generated/interfaces/display_message/Implementation.hpp>

#include "../Display.hpp"
#include <string>

// ev@75ac1216-19eb-4182-a85c-820f1fc2c091:v1
// insert your custom include headers here
// ev@75ac1216-19eb-4182-a85c-820f1fc2c091:v1

namespace module {
namespace display {

struct Conf {
std::string serial_port;
    int baudrate;
};

class display_messageImpl : public display_messageImplBase {
public:
    display_messageImpl() = delete;
    display_messageImpl(Everest::ModuleAdapter* ev, const Everest::PtrContainer<Display>& mod, Conf& config) :
        display_messageImplBase(ev, "display"), mod(mod), config(config){};

    // ev@8ea32d28-373f-4c90-ae5e-b4fcc74e2a61:v1
    // insert your public definitions here
    // ev@8ea32d28-373f-4c90-ae5e-b4fcc74e2a61:v1
// bool send_to_display(const std::string& message);
//bool send_display_packet(uint16_t vp_address, uint16_t value);   
static int open_serial_port(const std::string& port_name);
static void send_display_data(int fd, uint16_t vp_address, uint16_t value);
//};

protected:
    // command handler functions (virtual)
    types::display_message::SetDisplayMessageResponse
    handle_set_display_message(std::vector<types::display_message::DisplayMessage>& request) override;
    types::display_message::GetDisplayMessageResponse
    handle_get_display_messages(types::display_message::GetDisplayMessageRequest& request) override;
    types::display_message::ClearDisplayMessageResponse
    handle_clear_display_message(types::display_message::ClearDisplayMessageRequest& request) override;

    // ev@d2d1847a-7b88-41dd-ad07-92785f06f5c4:v1
    // insert your protected definitions here
    // ev@d2d1847a-7b88-41dd-ad07-92785f06f5c4:v1

private:
    const Everest::PtrContainer<Display>& mod;
    const Conf& config;

     void init() override;
     void ready() override;

    // ev@3370e4dd-95f4-47a9-aaec-ea76f34a66c9:v1
    // insert your private definitions here
    // ev@3370e4dd-95f4-47a9-aaec-ea76f34a66c9:v1
};

// ev@3d7da0ad-02c2-493d-9920-0bbbd56b9876:v1
// insert other definitions here
// ev@3d7da0ad-02c2-493d-9920-0bbbd56b9876:v1

} // namespace display
} // namespace module

#endif // DISPLAY_DISPLAY_MESSAGE_IMPL_HPP
