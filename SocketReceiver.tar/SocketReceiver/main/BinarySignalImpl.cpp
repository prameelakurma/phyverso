// SPDX-License-Identifier: Apache-2.0
// Copyright Pionix GmbH and Contributors to EVerest

#include "BinarySignalImpl.hpp"

#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <cstring>
#include <iostream>

namespace module {
namespace main {

void BinarySignalImpl::init() {
	 EVLOG_info << "BinarySignalImpl init()";
}

void BinarySignalImpl::ready() {
	 // Read socket path from module config
    socket_path = mod->config.socket_path;

    running = true;
    socket_thread = std::thread(&BinarySignalImpl::socket_loop, this);
}

void BinarySignalImpl::socket_loop() {
    int server_fd = -1;
    int client_fd = -1;

    sockaddr_un addr{};
    addr.sun_family = AF_UNIX;
    std::strncpy(addr.sun_path, socket_path.c_str(),
                 sizeof(addr.sun_path) - 1);

    // Remove old socket if exists
    unlink(socket_path.c_str());

    server_fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (server_fd < 0) {
        std::perror("[SocketReceiver] socket()");
        return;
    }

    if (bind(server_fd, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) < 0) {
        std::perror("[SocketReceiver] bind()");
        close(server_fd);
        return;
    }

    if (listen(server_fd, 1) < 0) {
        std::perror("[SocketReceiver] listen()");
        close(server_fd);
        return;
    }

    std::cout << "[SocketReceiver] Waiting for sender at "
              << socket_path << std::endl;

    client_fd = accept(server_fd, nullptr, nullptr);
    if (client_fd < 0) {
        std::perror("[SocketReceiver] accept()");
        close(server_fd);
        return;
    }

    std::cout << "[SocketReceiver] Sender connected" << std::endl;

    while (running) {
        uint8_t data = 0;
        ssize_t n = recv(client_fd, &data, sizeof(data), 0);

        if (n <= 0) {
            std::cout << "[SocketReceiver] Sender disconnected" << std::endl;
            break;
        }


    std::cout << "[SocketReceiver] Received raw value: "
              << static_cast<int>(data) << std::endl;
    }

    close(client_fd);
    close(server_fd);
    unlink(socket_path.c_str());
}

} // namespace main
} // namespace module
