// SPDX-License-Identifier: Apache-2.0
// Copyright Pionix GmbH and Contributors to EVerest
#include "SocketReceiver.hpp"

namespace module {

void SocketReceiver::init() {
    invoke_init(*p_main);
}

void SocketReceiver::ready() {
    invoke_ready(*p_main);
}

} // namespace module
