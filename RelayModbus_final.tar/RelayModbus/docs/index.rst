.. _everest_modules_handwritten_RelayModbus:

..  This file is a placeholder for optional multiple files
    handwritten documentation for the RelayModbus module.
    Please decide whether you want to use the doc.rst file
    or a set of files in the doc/ directory.
    In the latter case, you can delete the doc.rst file.
    In the former case, you can delete the doc/ directory.
    
..  This handwritten documentation is optional. In case
    you do not want to write it, you can delete this file
    and the doc/ directory.

..  The documentation can be written in reStructuredText,
    and will be converted to HTML and PDF by Sphinx.
    This index.rst file is the entry point for the module documentation.

*******************************************
RelayModbus
*******************************************

:ref:`Link <everest_modules_RelayModbus>` to the module's reference.
Modbus RTU relay control module over RS485 (e.g., Waveshare 8-relay module). Sends Modbus RTU commands to turn relays ON and OFF over UART (/dev/ttyS4).

