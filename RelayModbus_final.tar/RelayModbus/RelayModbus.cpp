// SPDX-License-Identifier: Apache-2.0
// Copyright Pionix GmbH and Contributors to EVerest
#include "RelayModbus.hpp"

namespace module {

void RelayModbus::init() {
    invoke_init(*p_relay);
}

void RelayModbus::ready() {
    invoke_ready(*p_relay);
}

} // namespace module
