// SPDX-License-Identifier: Apache-2.0
// Copyright Pionix GmbH
#ifndef RELAY_RELAY_MODBUS_IMPL_HPP
#define RELAY_RELAY_MODBUS_IMPL_HPP

#include <generated/interfaces/relay_modbus/Implementation.hpp>
#include "../RelayModbus.hpp"
#include <string>
#include <cstdint>
#include <atomic>

namespace module {
namespace relay {

class relay_modbusImpl : public relay_modbusImplBase {
public:
    relay_modbusImpl() = delete;

    relay_modbusImpl(Everest::ModuleAdapter* ev, const Everest::PtrContainer<RelayModbus>& mod,module::Conf& conf) :
        relay_modbusImplBase(ev, "relay"), mod(mod) {};

protected:
    void handle_set_state(int& relay, bool& state) override;
    bool handle_get_state(int& relay) override;
    int handle_get_num_relays() override;

private:
    const Everest::PtrContainer<RelayModbus>& mod;

    // Config values loaded from manifest.json
    std::string device;
    int slave_id = 1;
    int baudrate = 9600;
    int num_relays = 1;

    int uart_fd = -1;
    static std::atomic<bool> monitor_running;

    void init() override;
    void ready() override;

    int open_uart(const std::string& device, int baudrate);
    uint16_t modbus_crc16(uint8_t* buf, int len);
    int build_modbus_command(uint8_t* buffer, uint8_t slave_addr, uint16_t coil_addr, uint16_t state);
    void set_relay(int relay, bool state);
};

} // namespace relay
} // namespace module

#endif // RELAY_RELAY_MODBUS_IMPL_HPP

