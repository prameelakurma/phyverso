// SPDX-License-Identifier: Apache-2.0
// Copyright Pionix GmbH and Contributors to EVerest
#ifndef RELAY_RELAY_MODBUS_IMPL_HPP
#define RELAY_RELAY_MODBUS_IMPL_HPP

//
// AUTO GENERATED - MARKED REGIONS WILL BE KEPT
// template version 3
//

#include <generated/interfaces/relay_modbus/Implementation.hpp>

#include "../RelayModbus.hpp"
#include <string>
#include <cstdint>

// ev@75ac1216-19eb-4182-a85c-820f1fc2c091:v1
// insert your custom include headers here
// ev@75ac1216-19eb-4182-a85c-820f1fc2c091:v1

namespace module {
namespace relay {

struct Conf {
std::string device;
    int slave_id;
    int baudrate;
    int num_relays;
};

class relay_modbusImpl : public relay_modbusImplBase {
public:
    relay_modbusImpl() = delete;
    relay_modbusImpl(Everest::ModuleAdapter* ev, const Everest::PtrContainer<RelayModbus>& mod, Conf& config) :
        relay_modbusImplBase(ev, "relay"), mod(mod), config(config){};

    // ev@8ea32d28-373f-4c90-ae5e-b4fcc74e2a61:v1
    // insert your public definitions here
    // ev@8ea32d28-373f-4c90-ae5e-b4fcc74e2a61:v1

protected:
    // command handler functions (virtual)
    virtual void handle_set_state(int& relay, bool& state) override;
    virtual bool handle_get_state(int& relay) override;
    virtual int handle_get_num_relays() override;

    // ev@d2d1847a-7b88-41dd-ad07-92785f06f5c4:v1
    // insert your protected definitions here
    // ev@d2d1847a-7b88-41dd-ad07-92785f06f5c4:v1

private:
    const Everest::PtrContainer<RelayModbus>& mod;
    const Conf& config;

    virtual void init() override;
    virtual void ready() override;
    int uart_fd = -1;
    int open_uart(const std::string& device, int baudrate);
    uint16_t modbus_crc16(uint8_t *buf, int len);
    int build_modbus_command(uint8_t *buffer, uint8_t slave_addr, uint16_t coil_addr, uint16_t state);
    // ev@3370e4dd-95f4-47a9-aaec-ea76f34a66c9:v1
    // insert your private definitions here
    // ev@3370e4dd-95f4-47a9-aaec-ea76f34a66c9:v1
};

// ev@3d7da0ad-02c2-493d-9920-0bbbd56b9876:v1
// insert other definitions here
// ev@3d7da0ad-02c2-493d-9920-0bbbd56b9876:v1

} // namespace relay
} // namespace module

#endif // RELAY_RELAY_MODBUS_IMPL_HPP
