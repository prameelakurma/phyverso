#include "relay_modbusImpl.hpp"
#include <fcntl.h>
#include <termios.h>
#include <unistd.h>
#include <cstring>
#include <string>
#include <iostream>
#include <thread>
#include <chrono>

namespace module {
namespace relay {

// CRC16 calculation
uint16_t relay_modbusImpl::modbus_crc16(uint8_t *buf, int len) {
    uint16_t crc = 0xFFFF;
    for (int pos = 0; pos < len; pos++) {
        crc ^= (uint16_t)buf[pos];
        for (int i = 0; i < 8; i++) {
            if ((crc & 0x0001) != 0) {
                crc >>= 1;
                crc ^= 0xA001;
            } else {
                crc >>= 1;
            }
        }
    }
    return crc;
}

// Build Modbus command to write single coil (relay)
int relay_modbusImpl::build_modbus_command(uint8_t *buffer, uint8_t slave_addr, uint16_t coil_addr, uint16_t state) {
    buffer[0] = slave_addr;
    buffer[1] = 0x05;
    buffer[2] = coil_addr >> 8;
    buffer[3] = coil_addr & 0xFF;
    buffer[4] = (state == 0xFF00) ? 0xFF : 0x00;
    buffer[5] = 0x00;
    uint16_t crc = this->modbus_crc16(buffer, 6);
    buffer[6] = crc & 0xFF;
    buffer[7] = crc >> 8;
    return 8;
}

// Open UART device with configurable device and baudrate
int relay_modbusImpl::open_uart(const std::string& device, int baudrate) {
    int fd = open(device.c_str(), O_RDWR | O_NOCTTY | O_NDELAY);
    if (fd == -1) {
        std::cerr << "Unable to open UART: " << device << std::endl;
        return -1;
    }
    struct termios options;
    tcgetattr(fd, &options);

    // Set baudrate dynamically
    speed_t speed;
    switch (baudrate) {
        case 9600: speed = B9600; break;
        case 19200: speed = B19200; break;
        case 38400: speed = B38400; break;
        case 57600: speed = B57600; break;
        case 115200: speed = B115200; break;
        default: speed = B9600; break;
    }
    cfsetispeed(&options, speed);
    cfsetospeed(&options, speed);

    options.c_cflag |= (CLOCAL | CREAD);
    options.c_cflag &= ~CSIZE;
    options.c_cflag |= CS8;
    options.c_cflag &= ~PARENB;
    options.c_cflag &= ~CSTOPB;
    options.c_cflag &= ~CRTSCTS;
    tcsetattr(fd, TCSANOW, &options);
    return fd;
}

void relay_modbusImpl::init() {
    // Use config.device and config.baudrate from manifest
    uart_fd = open_uart(config.device, config.baudrate);
    std::cout << "UART device: " << config.device << std::endl;
    if (uart_fd < 0) {
        std::cerr << "Failed to open UART for relay control\n";
    }
}

// Helper to turn a relay ON or OFF (slave id from config)
void relay_modbusImpl::set_relay(int relay, bool state) {
    if (uart_fd < 0) {
        std::cerr << "UART not initialized\n";
        return;
    }
    uint8_t command[8];
    int len = build_modbus_command(command, static_cast<uint8_t>(config.slave_id), relay, state ? 0xFF00 : 0x0000);
    write(uart_fd, command, len);
    tcdrain(uart_fd);
    std::cout << "Relay " << relay << " set to " << (state ? "ON" : "OFF") << std::endl;
}

void relay_modbusImpl::ready() {
    int num_relays = config.num_relays; // from manifest
    // Turn ON all relays one by one
    for (int relay = 0; relay < num_relays; relay++) {
        set_relay(relay, true);
        std::this_thread::sleep_for(std::chrono::seconds(5));
    }
    std::this_thread::sleep_for(std::chrono::seconds(10));
    // Turn OFF all relays one by one
    for (int relay = 0; relay < num_relays; relay++) {
        set_relay(relay, false);
        std::this_thread::sleep_for(std::chrono::seconds(5));
    }
    std::this_thread::sleep_for(std::chrono::seconds(10));
}

void relay_modbusImpl::handle_set_state(int& relay, bool& state) {
    set_relay(relay, state);
}

bool relay_modbusImpl::handle_get_state(int& relay) {
    std::cerr << "Read state not implemented in this example\n";
    return true;
}

int relay_modbusImpl::handle_get_num_relays() {
    return config.num_relays; // from manifest
}

} // namespace relay
} // namespace module
